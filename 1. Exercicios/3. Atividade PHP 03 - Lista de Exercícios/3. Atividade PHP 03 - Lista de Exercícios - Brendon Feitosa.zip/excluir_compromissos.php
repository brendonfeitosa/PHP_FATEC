<!DOCTYPE html>
<html>

<head>
    <title>Compromissos
        <?php echo $usuario; ?></title>
</head>

<body>
    <h1>Compromissos de

        <body>
            <h1>Compromiss
                                                                                                                                                     <th>ID</th>
                                                                                                                                                    <th>Compromisso</th>
                                                                                                                                                    <th>Local</th>



                                                                                                                                                    <table>
                                                                                                                                                        <thead>
                                                                                                                                                            <tr>
                                                                                                                                                                <th>ID</th>
                                                                                                                                                                <th>Compromisso</th>
                                                                                                                                                                <th>Local</th>


                                                                                                                                                                <table>
                                                                                                                                                                    <thead>
                                                                                                                                                                        <tr>
                                                                                                                                                                            <th>ID</th>
                                                                                                                                                                            <th>Compromisso</th>



                                                                                                                                                                            <table>
                                                                                                                                                                                <thead>
                                                                                                                                                                                    <tr>
                                                                                                                                                                                        <th>ID</th>
                                                                                                                                                                                        <th>Compromisso</th>


                                                                                                                                                                                        <table>
                                                                                                                                                                                            <thead>
                                                                                                                                                                                                <tr>
                                                                                                                                                                                                    <th>ID</th>



                                                                                                                                                                                                    <table>
                                                                                                                                                                                                        <thead>
                                                                                                                                                                                                            <tr>
                                                                                                                                                                                                                <th>ID</th>


                                                                                                                                                                                                                <table>
                                                                                                                                                                                                                    <thead>
                                                                                                                                                                                                                        <tr>



                                                                                                                                                                                                                            <table>
                                                                                                                                                                                                                                <thead>
                                                                                                                                                                                                                                    <tr>


                                                                                                                                                                                                                                        < <?php foreach ($compromissos_filtrados as $compromisso) : ?> <tr>
                                                                                                                                                                                                                                            <td>
                                                                                                                                                                                                                                    <tr>


                                                                                                                                                                                                                                    <tr>


                                                                                                                                                                                                                                        <?php echo $compromisso['id']; ?></td>
                                                                                                                                                                                                                                        <td>
                                                                                                                                                                                                                                        <td < <?php echo $compromisso['compromisso']; ?></td>
                                                                                                                                                                                                                                        <td>

                                                                                                                                                                                                                                            <?php echo $compromisso['local']; ?></td>
                                                                                                                                                                                                                                        <td>
                                                                                                                                                                                                                                        <td <?php echo $compromisso['data']; ?></td>
                                                                                                                                                                                                                                        <td>
                                                                                                                                                                                                                                        <td <?php echo $compromisso['hora']; ?></td>
                                                                                                                                                                                                                                        <td>
                                                                                                                                                                                                                                            <form method=<td>


                                                                                                                                                                                                                                        <td>


                                                                                                                                                                                                                                            "post">
                                                                                                                                                                                                                                            <input type="hidden" name="id" value="<?php echo $compromisso['id']; ?>">
                                                                                                                                                                                                                                            <input type=<input type "submit" name="excluir" value="Excluir">
                                                                                                                                                                                                                                            </form>
                                                                                                                                                                                                                                        </td>
                                                                                                                                                                                                                                    </tr>

                                                                                                                                                                                                                                    </form>
                                                                                                                                                                                                                                    </td>
                                                                                                                                                                                                                        </tr>


                                                                                                                                                                                                                        </form>
                                                                                                                                                                                                                        </td>
                                                                                                                                                                                                            </tr>

                                                                                                                                                                                                            </form>
                                                                                                                                                                                                            </td>


                                                                                                                                                                                                            </form>
                                                                                                                                                                                                            </td>

                                                                                                                                                                                                            </form>


                                                                                                                                                                                                            </form>


                                                                                                                                                                                                        <?php endforeach; ?>
                                    </tbody>
                                </table>

                                <a href=</tbody>
                        </table>

                        <a href </tbody>
                </table>

                < </tbody>
                    </table>



                    </tbody>
                    </table>


                    </tbody>


                    </tbody>


                    "selecionar_usuario.php">Voltar</a>
        </body>

</html>